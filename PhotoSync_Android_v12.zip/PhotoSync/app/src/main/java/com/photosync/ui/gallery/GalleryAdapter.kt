package com.photosync.ui.gallery

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photosync.data.drive.DriveService
import com.photosync.databinding.ItemGalleryPhotoBinding

class GalleryAdapter :
    ListAdapter<DriveService.DrivePhoto, GalleryAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val binding: ItemGalleryPhotoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(photo: DriveService.DrivePhoto) {
            binding.tvPhotoName.text = photo.name
            binding.tvPhotoSize.text = formatSize(photo.size)

            if (photo.thumbnailLink != null) {
                Glide.with(binding.root)
                    .load(photo.thumbnailLink)
                    .centerCrop()
                    .into(binding.ivPhoto)
            } else {
                binding.ivPhoto.setImageResource(android.R.drawable.ic_menu_gallery)
            }
        }

        private fun formatSize(bytes: Long): String = when {
            bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
            bytes >= 1_000 -> "%.0f KB".format(bytes / 1_000.0)
            else -> "$bytes B"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemGalleryPhotoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(getItem(position))

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<DriveService.DrivePhoto>() {
            override fun areItemsTheSame(a: DriveService.DrivePhoto, b: DriveService.DrivePhoto) =
                a.id == b.id
            override fun areContentsTheSame(a: DriveService.DrivePhoto, b: DriveService.DrivePhoto) =
                a == b
        }
    }
}
