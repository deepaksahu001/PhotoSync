package com.photosync.util

import java.io.File
import java.security.MessageDigest

/**
 * Generates SHA-256 hash of a file.
 * Used to detect duplicate photos before uploading.
 * Two identical photos — even with different filenames — will produce the same hash.
 */
object HashUtil {

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { stream ->
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (stream.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
