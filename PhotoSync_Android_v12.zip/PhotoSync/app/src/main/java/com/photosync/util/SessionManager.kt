package com.photosync.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Stores and retrieves the currently logged-in Google account details.
 */
class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("photosync_prefs", Context.MODE_PRIVATE)

    var accountName: String?
        get() = prefs.getString(KEY_ACCOUNT_NAME, null)
        set(value) = prefs.edit().putString(KEY_ACCOUNT_NAME, value).apply()

    var displayName: String?
        get() = prefs.getString(KEY_DISPLAY_NAME, null)
        set(value) = prefs.edit().putString(KEY_DISPLAY_NAME, value).apply()

    var email: String?
        get() = prefs.getString(KEY_EMAIL, null)
        set(value) = prefs.edit().putString(KEY_EMAIL, value).apply()

    val isLoggedIn: Boolean
        get() = accountName != null

    /** Folder name used in Drive — derived from display name, safe for folder names */
    val driveFolderName: String
        get() = (displayName ?: accountName ?: "Unknown")
            .replace(Regex("[^a-zA-Z0-9_\\- ]"), "")
            .trim()
            .replace(" ", "_")

    fun logout() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_ACCOUNT_NAME = "account_name"
        private const val KEY_DISPLAY_NAME = "display_name"
        private const val KEY_EMAIL = "email"
    }
}
