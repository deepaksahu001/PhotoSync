package com.photosync.ui.gallery

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photosync.databinding.ItemGalleryPhotoBinding

data class PhotoItem(
    val id: String,
    val name: String,
    val thumbnailLink: String?,
    val size: Long,
    val createdTime: String
)

class GalleryAdapter : ListAdapter<PhotoItem, GalleryAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val binding: ItemGalleryPhotoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(photo: PhotoItem) {
            binding.tvPhotoName.text = photo.name
            binding.tvPhotoSize.text = formatSize(photo.size)

            if (photo.thumbnailLink != null) {
                Glide.with(binding.root)
                    .load(photo.thumbnailLink)
                    .centerCrop()
                    .into(binding.ivPhoto)
            } else {
                binding.ivPhoto.setImageResource(android.R.drawable.ic_menu_gallery)
            }
        }

        private fun formatSize(bytes: Long): String = when {
            bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
            bytes >= 1_000 -> "%.0f KB".format(bytes / 1_000.0)
            else -> "$bytes B"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemGalleryPhotoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(getItem(position))

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<PhotoItem>() {
            override fun areItemsTheSame(a: PhotoItem, b: PhotoItem) = a.id == b.id
            override fun areContentsTheSame(a: PhotoItem, b: PhotoItem) = a == b
        }
    }
}
