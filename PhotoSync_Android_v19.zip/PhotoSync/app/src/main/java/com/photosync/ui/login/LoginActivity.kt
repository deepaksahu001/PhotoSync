package com.photosync.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import com.photosync.databinding.ActivityLoginBinding
import com.photosync.ui.home.HomeActivity
import com.photosync.util.SessionManager

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var session: SessionManager

    companion object {
        private const val RC_SIGN_IN = 100
        private const val RC_DRIVE_AUTH = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        if (session.isLoggedIn) {
            startHome()
            return
        }

        setupGoogleSignIn()

        binding.btnGoogleSignIn.setOnClickListener {
            showLoading(true)
            startActivityForResult(googleSignInClient.signInIntent, RC_SIGN_IN)
        }
    }

    private fun setupGoogleSignIn() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(
                Scope("https://www.googleapis.com/auth/drive")
            )
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            RC_SIGN_IN -> {
                try {
                    val account = GoogleSignIn.getSignedInAccountFromIntent(data)
                        .getResult(ApiException::class.java)
                    handleSignInSuccess(account)
                } catch (e: ApiException) {
                    showLoading(false)
                    Toast.makeText(this, "Sign-in failed: ${e.statusCode}", Toast.LENGTH_LONG).show()
                }
            }
            RC_DRIVE_AUTH -> {
                if (resultCode == RESULT_OK) {
                    startHome()
                } else {
                    showLoading(false)
                    Toast.makeText(this, "Drive access zaroori hai", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun handleSignInSuccess(account: GoogleSignInAccount) {
        session.accountName = account.account?.name
        session.displayName = account.displayName
        session.email = account.email
        startHome()
    }

    private fun startHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnGoogleSignIn.isEnabled = !show
    }
}
