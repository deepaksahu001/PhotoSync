package com.photosync.data.drive

import android.content.Context
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.photosync.util.HashUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * DriveService — Shared Drive version
 * All photos go into: PhotoSync_Project (Shared Drive) / UserName / Date /
 */
class DriveService(context: Context, accountName: String) {

    companion object {
        // Shared Drive ID
        const val SHARED_DRIVE_ID = "1EJSNzxF7u4_9x-5kR6oU7Y-cX6e7T6FJ"
        const val HASHES_FILE_NAME = "hashes.json"
        const val MIME_FOLDER = "application/vnd.google-apps.folder"
        const val MIME_JSON = "application/json"
        const val MIME_JPEG = "image/jpeg"
    }

    private val credential = GoogleAccountCredential
        .usingOAuth2(context, listOf(DriveScopes.DRIVE))
        .also { it.selectedAccountName = accountName }

    private val driveService = Drive.Builder(
        NetHttpTransport(),
        GsonFactory.getDefaultInstance(),
        credential
    ).setApplicationName("PhotoSync").build()

    private val gson = Gson()

    // ─── Folder helpers ────────────────────────────────────────────────────────

    /** Find folder by name inside a parent within Shared Drive */
    private suspend fun findFolder(name: String, parentId: String): String? =
        withContext(Dispatchers.IO) {
            val result = driveService.files().list()
                .setQ("name='$name' and mimeType='$MIME_FOLDER' and '$parentId' in parents and trashed=false")
                .setFields("files(id)")
                .setSupportsAllDrives(true)
                .setIncludeItemsFromAllDrives(true)
                .execute()
            result.files.firstOrNull()?.id
        }

    /** Create folder inside parent within Shared Drive */
    private suspend fun createFolder(name: String, parentId: String): String =
        withContext(Dispatchers.IO) {
            val meta = DriveFile().apply {
                this.name = name
                mimeType = MIME_FOLDER
                parents = listOf(parentId)
            }
            driveService.files().create(meta)
                .setFields("id")
                .setSupportsAllDrives(true)
                .execute().id
        }

    /** Find or create folder */
    private suspend fun findOrCreateFolder(name: String, parentId: String): String =
        findFolder(name, parentId) ?: createFolder(name, parentId)

    /**
     * Ensure folder path exists in Shared Drive:
     * Shared Drive / UserName / yyyy-MM-dd
     */
    suspend fun ensureUserDateFolder(userName: String): String {
        val userId   = findOrCreateFolder(userName, SHARED_DRIVE_ID)
        val today    = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        return findOrCreateFolder(today, userId)
    }

    /** Get user's root folder in Shared Drive */
    suspend fun getUserFolderId(userName: String): String =
        findOrCreateFolder(userName, SHARED_DRIVE_ID)

    // ─── Hash management ───────────────────────────────────────────────────────

    suspend fun loadHashes(userName: String): MutableSet<String> =
        withContext(Dispatchers.IO) {
            try {
                val userFolderId = getUserFolderId(userName)
                val result = driveService.files().list()
                    .setQ("name='$HASHES_FILE_NAME' and '$userFolderId' in parents and trashed=false")
                    .setFields("files(id)")
                    .setSupportsAllDrives(true)
                    .setIncludeItemsFromAllDrives(true)
                    .execute()
                val fileId = result.files.firstOrNull()?.id ?: return@withContext mutableSetOf()
                val out = ByteArrayOutputStream()
                driveService.files().get(fileId)
                    .setSupportsAllDrives(true)
                    .executeMediaAndDownloadTo(out)
                val json = out.toString("UTF-8")
                val type = object : TypeToken<MutableSet<String>>() {}.type
                gson.fromJson(json, type) ?: mutableSetOf()
            } catch (e: Exception) {
                mutableSetOf()
            }
        }

    suspend fun saveHashes(userName: String, hashes: Set<String>) =
        withContext(Dispatchers.IO) {
            val userFolderId = getUserFolderId(userName)
            val json = gson.toJson(hashes)
            val tempFile = File.createTempFile("hashes", ".json")
            tempFile.writeText(json)

            val result = driveService.files().list()
                .setQ("name='$HASHES_FILE_NAME' and '$userFolderId' in parents and trashed=false")
                .setFields("files(id)")
                .setSupportsAllDrives(true)
                .setIncludeItemsFromAllDrives(true)
                .execute()

            val existing = result.files.firstOrNull()?.id
            if (existing != null) {
                val content = FileContent(MIME_JSON, tempFile)
                driveService.files().update(existing, DriveFile(), content)
                    .setSupportsAllDrives(true)
                    .execute()
            } else {
                val meta = DriveFile().apply {
                    name = HASHES_FILE_NAME
                    parents = listOf(userFolderId)
                }
                val content = FileContent(MIME_JSON, tempFile)
                driveService.files().create(meta, content)
                    .setFields("id")
                    .setSupportsAllDrives(true)
                    .execute()
            }
            tempFile.delete()
        }

    // ─── Photo upload ──────────────────────────────────────────────────────────

    data class UploadResult(
        val success: Boolean,
        val isDuplicate: Boolean = false,
        val fileId: String? = null,
        val fileName: String = "",
        val errorMessage: String? = null
    )

    suspend fun uploadPhoto(
        localFile: File,
        userName: String,
        onProgress: ((Int) -> Unit)? = null
    ): UploadResult = withContext(Dispatchers.IO) {
        try {
            val hash = HashUtil.sha256(localFile)
            val hashes = loadHashes(userName)

            if (hashes.contains(hash)) {
                return@withContext UploadResult(
                    success = true,
                    isDuplicate = true,
                    fileName = localFile.name
                )
            }

            val dateFolderId = ensureUserDateFolder(userName)

            val meta = DriveFile().apply {
                name = localFile.name
                parents = listOf(dateFolderId)
            }
            val content = FileContent(MIME_JPEG, localFile)
            onProgress?.invoke(30)

            val uploaded = driveService.files()
                .create(meta, content)
                .setFields("id, name, size")
                .setSupportsAllDrives(true)
                .execute()

            onProgress?.invoke(90)
            hashes.add(hash)
            saveHashes(userName, hashes)
            onProgress?.invoke(100)

            UploadResult(
                success = true,
                isDuplicate = false,
                fileId = uploaded.id,
                fileName = uploaded.name
            )
        } catch (e: Exception) {
            UploadResult(
                success = false,
                fileName = localFile.name,
                errorMessage = "${e.javaClass.simpleName}: ${e.message ?: \"unknown\"}"
            )
        }
    }

    // ─── Gallery ──────────────────────────────────────────────────────────────

    data class DrivePhoto(
        val id: String,
        val name: String,
        val thumbnailLink: String?,
        val size: Long,
        val createdTime: String
    )

    suspend fun listUserPhotos(userName: String): List<DrivePhoto> =
        withContext(Dispatchers.IO) {
            try {
                val userFolderId = getUserFolderId(userName)
                val dateFolders = driveService.files().list()
                    .setQ("mimeType='$MIME_FOLDER' and '$userFolderId' in parents and trashed=false")
                    .setFields("files(id)")
                    .setSupportsAllDrives(true)
                    .setIncludeItemsFromAllDrives(true)
                    .execute().files

                val allPhotos = mutableListOf<DrivePhoto>()
                for (folder in dateFolders) {
                    val photos = driveService.files().list()
                        .setQ("mimeType='$MIME_JPEG' and '${folder.id}' in parents and trashed=false")
                        .setFields("files(id, name, thumbnailLink, size, createdTime)")
                        .setSupportsAllDrives(true)
                        .setIncludeItemsFromAllDrives(true)
                        .execute().files

                    photos.forEach { f ->
                        allPhotos.add(DrivePhoto(
                            id = f.id,
                            name = f.name,
                            thumbnailLink = f.thumbnailLink,
                            size = f.getSize() ?: 0L,
                            createdTime = f.createdTime?.toStringRfc3339() ?: ""
                        ))
                    }
                }
                allPhotos.sortedByDescending { it.createdTime }
            } catch (e: Exception) {
                emptyList()
            }
        }
}
