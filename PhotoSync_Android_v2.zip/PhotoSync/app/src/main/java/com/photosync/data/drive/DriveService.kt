package com.photosync.data.drive

import android.content.Context
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * DriveService handles all Google Drive operations:
 *  - Creates folder structure: PhotoSync_Project / UserName / yyyy-MM-dd / photos
 *  - Uploads photos at original resolution
 *  - Manages hashes.json per user to prevent duplicate uploads
 */
class DriveService(context: Context, accountName: String) {

    companion object {
        const val ROOT_FOLDER_NAME = "PhotoSync_Project"
        const val HASHES_FILE_NAME = "hashes.json"
        const val MIME_FOLDER = "application/vnd.google-apps.folder"
        const val MIME_JSON = "application/json"
        const val MIME_JPEG = "image/jpeg"
    }

    private val credential = GoogleAccountCredential
        .usingOAuth2(context, listOf(DriveScopes.DRIVE_FILE))
        .also { it.selectedAccountName = accountName }

    private val driveService = Drive.Builder(
        NetHttpTransport(),
        GsonFactory.getDefaultInstance(),
        credential
    ).setApplicationName("PhotoSync").build()

    private val gson = Gson()

    // ─── Folder helpers ────────────────────────────────────────────────────────

    /** Find a folder by name inside a parent, or null if not found */
    private suspend fun findFolder(name: String, parentId: String): String? =
        withContext(Dispatchers.IO) {
            val result = driveService.files().list()
                .setQ("name='$name' and mimeType='$MIME_FOLDER' and '$parentId' in parents and trashed=false")
                .setFields("files(id)")
                .execute()
            result.files.firstOrNull()?.id
        }

    /** Create a folder inside a parent, return its ID */
    private suspend fun createFolder(name: String, parentId: String): String =
        withContext(Dispatchers.IO) {
            val meta = DriveFile().apply {
                this.name = name
                mimeType = MIME_FOLDER
                parents = listOf(parentId)
            }
            driveService.files().create(meta).setFields("id").execute().id
        }

    /** Find or create a folder, return its ID */
    private suspend fun findOrCreateFolder(name: String, parentId: String): String =
        findFolder(name, parentId) ?: createFolder(name, parentId)

    /** Get the Drive root ("My Drive") folder ID */
    private suspend fun getRootId(): String =
        withContext(Dispatchers.IO) { "root" }

    /**
     * Ensure full folder path exists and return the date folder ID:
     *   My Drive / PhotoSync_Project / {userName} / {today's date}
     */
    suspend fun ensureUserDateFolder(userName: String): String {
        val root       = getRootId()
        val projectId  = findOrCreateFolder(ROOT_FOLDER_NAME, root)
        val userId     = findOrCreateFolder(userName, projectId)
        val today      = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        return findOrCreateFolder(today, userId)
    }

    /** Return the user's root folder ID (PhotoSync_Project / userName) */
    suspend fun getUserFolderId(userName: String): String {
        val root      = getRootId()
        val projectId = findOrCreateFolder(ROOT_FOLDER_NAME, root)
        return findOrCreateFolder(userName, projectId)
    }

    // ─── Hash management ───────────────────────────────────────────────────────

    /** Download and parse hashes.json from the user's folder */
    suspend fun loadHashes(userName: String): MutableSet<String> =
        withContext(Dispatchers.IO) {
            try {
                val userFolderId = getUserFolderId(userName)
                val result = driveService.files().list()
                    .setQ("name='$HASHES_FILE_NAME' and '$userFolderId' in parents and trashed=false")
                    .setFields("files(id)")
                    .execute()
                val fileId = result.files.firstOrNull()?.id ?: return@withContext mutableSetOf()
                val out = ByteArrayOutputStream()
                driveService.files().get(fileId).executeMediaAndDownloadTo(out)
                val json = out.toString("UTF-8")
                val type = object : TypeToken<MutableSet<String>>() {}.type
                gson.fromJson(json, type) ?: mutableSetOf()
            } catch (e: Exception) {
                mutableSetOf()
            }
        }

    /** Upload (or overwrite) hashes.json in the user's folder */
    suspend fun saveHashes(userName: String, hashes: Set<String>) =
        withContext(Dispatchers.IO) {
            val userFolderId = getUserFolderId(userName)
            val json = gson.toJson(hashes)
            val tempFile = File.createTempFile("hashes", ".json")
            tempFile.writeText(json)

            val result = driveService.files().list()
                .setQ("name='$HASHES_FILE_NAME' and '$userFolderId' in parents and trashed=false")
                .setFields("files(id)")
                .execute()

            val existing = result.files.firstOrNull()?.id
            if (existing != null) {
                // Update existing file
                val content = FileContent(MIME_JSON, tempFile)
                driveService.files().update(existing, DriveFile(), content).execute()
            } else {
                // Create new file
                val meta = DriveFile().apply {
                    name = HASHES_FILE_NAME
                    parents = listOf(userFolderId)
                }
                val content = FileContent(MIME_JSON, tempFile)
                driveService.files().create(meta, content).setFields("id").execute()
            }
            tempFile.delete()
        }

    // ─── Photo upload ──────────────────────────────────────────────────────────

    data class UploadResult(
        val success: Boolean,
        val isDuplicate: Boolean = false,
        val fileId: String? = null,
        val fileName: String = "",
        val errorMessage: String? = null
    )

    /**
     * Upload a single photo:
     *  1. Compute SHA-256 hash of the file
     *  2. Check against stored hashes — skip if duplicate
     *  3. Upload to Drive at original resolution
     *  4. Save updated hashes
     */
    suspend fun uploadPhoto(
        localFile: File,
        userName: String,
        onProgress: ((Int) -> Unit)? = null
    ): UploadResult = withContext(Dispatchers.IO) {
        try {
            val hash = HashUtil.sha256(localFile)

            // Load existing hashes
            val hashes = loadHashes(userName)

            if (hashes.contains(hash)) {
                return@withContext UploadResult(
                    success = true,
                    isDuplicate = true,
                    fileName = localFile.name
                )
            }

            // Get or create date folder
            val dateFolderId = ensureUserDateFolder(userName)

            // Upload at original resolution — no compression
            val meta = DriveFile().apply {
                name = localFile.name
                parents = listOf(dateFolderId)
            }
            val content = FileContent(MIME_JPEG, localFile)
            onProgress?.invoke(30)

            val uploaded = driveService.files()
                .create(meta, content)
                .setFields("id, name, size")
                .execute()

            onProgress?.invoke(90)

            // Save hash
            hashes.add(hash)
            saveHashes(userName, hashes)

            onProgress?.invoke(100)

            UploadResult(
                success = true,
                isDuplicate = false,
                fileId = uploaded.id,
                fileName = uploaded.name
            )

        } catch (e: Exception) {
            UploadResult(
                success = false,
                fileName = localFile.name,
                errorMessage = e.message
            )
        }
    }

    // ─── Gallery listing ───────────────────────────────────────────────────────

    data class DrivePhoto(
        val id: String,
        val name: String,
        val thumbnailLink: String?,
        val size: Long,
        val createdTime: String
    )

    /** List all photos uploaded by this user (across all date folders) */
    suspend fun listUserPhotos(userName: String): List<DrivePhoto> =
        withContext(Dispatchers.IO) {
            try {
                val userFolderId = getUserFolderId(userName)
                val result = driveService.files().list()
                    .setQ("mimeType='$MIME_JPEG' and '$userFolderId' in parents and trashed=false")
                    .setFields("files(id, name, thumbnailLink, size, createdTime)")
                    .setOrderBy("createdTime desc")
                    .execute()

                // Also search inside date subfolders
                val allPhotos = mutableListOf<DrivePhoto>()

                // Get date folders
                val dateFolders = driveService.files().list()
                    .setQ("mimeType='$MIME_FOLDER' and '$userFolderId' in parents and trashed=false")
                    .setFields("files(id)")
                    .execute().files

                for (folder in dateFolders) {
                    val photos = driveService.files().list()
                        .setQ("mimeType='$MIME_JPEG' and '${folder.id}' in parents and trashed=false")
                        .setFields("files(id, name, thumbnailLink, size, createdTime)")
                        .setOrderBy("createdTime desc")
                        .execute().files

                    photos.forEach { f ->
                        allPhotos.add(
                            DrivePhoto(
                                id = f.id,
                                name = f.name,
                                thumbnailLink = f.thumbnailLink,
                                size = f.getSize() ?: 0L,
                                createdTime = f.createdTime?.toStringRfc3339() ?: ""
                            )
                        )
                    }
                }

                allPhotos.sortedByDescending { it.createdTime }
            } catch (e: Exception) {
                emptyList()
            }
        }
}
