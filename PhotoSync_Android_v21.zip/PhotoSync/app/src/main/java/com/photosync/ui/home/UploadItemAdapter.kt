package com.photosync.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.photosync.R
import com.photosync.databinding.ItemUploadBinding
import com.photosync.ui.home.HomeViewModel.UploadItemState
import com.photosync.ui.home.HomeViewModel.UploadItemState.Status

class UploadItemAdapter :
    ListAdapter<UploadItemState, UploadItemAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val binding: ItemUploadBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: UploadItemState) {
            binding.tvFileName.text = item.fileName
            binding.tvFileSize.text = item.sizeLabel
            binding.progressBar.progress = item.progress

            val ctx = binding.root.context

            when (item.status) {
                Status.PENDING -> {
                    binding.tvStatus.text = "Ready..."
                    binding.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.gray))
                    binding.ivStatus.setImageResource(R.drawable.ic_pending)
                    binding.progressBar.visibility = android.view.View.VISIBLE
                }
                Status.UPLOADING -> {
                    binding.tvStatus.text = "Uploading... ${item.progress}%"
                    binding.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.blue))
                    binding.ivStatus.setImageResource(R.drawable.ic_uploading)
                    binding.progressBar.visibility = android.view.View.VISIBLE
                }
                Status.DONE -> {
                    binding.tvStatus.text = "Uploaded successfully"
                    binding.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.green))
                    binding.ivStatus.setImageResource(R.drawable.ic_done)
                    binding.progressBar.visibility = android.view.View.GONE
                }
                Status.DUPLICATE -> {
                    binding.tvStatus.text = "Duplicate — skipped"
                    binding.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.orange))
                    binding.ivStatus.setImageResource(R.drawable.ic_duplicate)
                    binding.progressBar.visibility = android.view.View.GONE
                }
                Status.ERROR -> {
                    binding.tvStatus.text = "Error: ${item.errorMessage}"
                    binding.tvStatus.setTextColor(ContextCompat.getColor(ctx, R.color.red))
                    binding.ivStatus.setImageResource(R.drawable.ic_error)
                    binding.progressBar.visibility = android.view.View.GONE
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemUploadBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(getItem(position))

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<UploadItemState>() {
            override fun areItemsTheSame(a: UploadItemState, b: UploadItemState) =
                a.fileName == b.fileName
            override fun areContentsTheSame(a: UploadItemState, b: UploadItemState) = a == b
        }
    }
}
