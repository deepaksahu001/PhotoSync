package com.photosync.ui.gallery

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.photosync.data.drive.DriveService
import com.photosync.databinding.ActivityGalleryBinding
import com.photosync.util.SessionManager
import kotlinx.coroutines.launch

class GalleryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryBinding
    private lateinit var session: SessionManager
    private lateinit var adapter: GalleryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        supportActionBar?.apply {
            title = "Drive Gallery"
            setDisplayHomeAsUpEnabled(true)
        }

        adapter = GalleryAdapter()
        binding.rvGallery.apply {
            layoutManager = GridLayoutManager(this@GalleryActivity, 2)
            adapter = this@GalleryActivity.adapter
        }

        loadPhotos()
    }

    private fun loadPhotos() {
        val accountName = session.accountName ?: return
        val folderName = session.driveFolderName

        binding.progressBar.visibility = View.VISIBLE
        binding.tvEmpty.visibility = View.GONE

        lifecycleScope.launch {
            val driveService = DriveService(this@GalleryActivity, accountName)
            val photos = driveService.listUserPhotos(folderName).map {
                PhotoItem(
                    id = it.id,
                    name = it.name,
                    thumbnailLink = it.thumbnailLink,
                    size = it.size,
                    createdTime = it.createdTime
                )
            }

            binding.progressBar.visibility = View.GONE

            if (photos.isEmpty()) {
                binding.tvEmpty.visibility = View.VISIBLE
                binding.tvCount.text = "0 Photos"
            } else {
                binding.tvCount.text = "${photos.size} Photos • Google Drive"
                adapter.submitList(photos)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
