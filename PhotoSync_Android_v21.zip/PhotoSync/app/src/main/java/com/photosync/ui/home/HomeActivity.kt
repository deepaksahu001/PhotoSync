package com.photosync.ui.home

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.photosync.databinding.ActivityHomeBinding
import com.photosync.ui.gallery.GalleryActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var uploadAdapter: UploadItemAdapter
    private var cameraImageFile: File? = null

    // Camera launcher
    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            cameraImageFile?.let { viewModel.uploadPhotos(listOf(it)) }
        }
    }

    // Gallery launcher (multiple photos)
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val files = mutableListOf<File>()
            val clipData = result.data?.clipData
            if (clipData != null) {
                for (i in 0 until clipData.itemCount) {
                    uriToFile(clipData.getItemAt(i).uri)?.let { files.add(it) }
                }
            } else {
                result.data?.data?.let { uri ->
                    uriToFile(uri)?.let { files.add(it) }
                }
            }
            if (files.isNotEmpty()) viewModel.uploadPhotos(files)
        }
    }

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        if (granted) pendingAction?.invoke()
        pendingAction = null
    }

    private var pendingAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        // User info
        binding.tvInitials.text = viewModel.getInitials()
        binding.tvWelcome.text = "Hello, ${viewModel.getDisplayName()}"

        // Upload buttons
        binding.btnCamera.setOnClickListener { requestCameraAndOpen() }
        binding.btnGallery.setOnClickListener { requestGalleryAndOpen() }

        // Gallery screen
        binding.btnViewGallery.setOnClickListener {
            startActivity(Intent(this, GalleryActivity::class.java))
        }

        // RecyclerView for upload items
        uploadAdapter = UploadItemAdapter()
        binding.rvUploads.apply {
            layoutManager = LinearLayoutManager(this@HomeActivity)
            adapter = uploadAdapter
        }
    }

    private fun observeViewModel() {
        viewModel.uploadResults.observe(this) { items ->
            binding.rvUploads.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
            uploadAdapter.submitList(items)
        }

        viewModel.isUploading.observe(this) { uploading ->
            binding.progressBar.visibility = if (uploading) View.VISIBLE else View.GONE
        }

        viewModel.uploadStats.observe(this) { stats ->
            binding.tvUploaded.text = stats.uploaded.toString()
            binding.tvDuplicates.text = stats.duplicates.toString()
        }
    }

    // ─── Camera ───────────────────────────────────────────────────────────────

    private fun requestCameraAndOpen() {
        val perms = arrayOf(Manifest.permission.CAMERA)
        if (hasPermissions(perms)) {
            openCamera()
        } else {
            pendingAction = { openCamera() }
            permissionLauncher.launch(perms)
        }
    }

    private fun openCamera() {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val imageFile = File(cacheDir, "PHOTO_$timestamp.jpg")
        cameraImageFile = imageFile
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", imageFile)
        cameraLauncher.launch(uri)
    }

    // ─── Gallery ──────────────────────────────────────────────────────────────

    private fun requestGalleryAndOpen() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (hasPermissions(perms)) {
            openGallery()
        } else {
            pendingAction = { openGallery() }
            permissionLauncher.launch(perms)
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        galleryLauncher.launch(intent)
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private fun hasPermissions(perms: Array<String>) =
        perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    private fun uriToFile(uri: Uri): File? {
        return try {
            // Get original filename from URI
            val cursor = contentResolver.query(uri, null, null, null, null)
            val originalName = cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) it.getString(nameIndex) else null
                } else null
            } ?: "photo_${System.currentTimeMillis()}.jpg"
            
            val inputStream = contentResolver.openInputStream(uri) ?: return null
            val file = File(cacheDir, originalName)
            file.outputStream().use { out -> inputStream.copyTo(out) }
            file
        } catch (e: Exception) {
            null
        }
    }
}
