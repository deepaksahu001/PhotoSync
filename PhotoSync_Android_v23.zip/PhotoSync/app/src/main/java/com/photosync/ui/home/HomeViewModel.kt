package com.photosync.ui.home

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.photosync.data.drive.DriveService
import com.photosync.util.SessionManager
import kotlinx.coroutines.launch
import java.io.File

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val session = SessionManager(application)

    // SharedPreferences to persist stats across reboots
    private val prefs = application.getSharedPreferences("upload_stats", Context.MODE_PRIVATE)

    private val _uploadResults = MutableLiveData<List<UploadItemState>>()
    val uploadResults: LiveData<List<UploadItemState>> = _uploadResults

    private val _isUploading = MutableLiveData(false)
    val isUploading: LiveData<Boolean> = _isUploading

    private val _uploadStats = MutableLiveData(loadSavedStats())
    val uploadStats: LiveData<UploadStats> = _uploadStats

    data class UploadItemState(
        val fileName: String,
        val status: Status,
        val progress: Int = 0,
        val sizeLabel: String = "",
        val errorMessage: String? = null
    ) {
        enum class Status { PENDING, UPLOADING, DONE, DUPLICATE, ERROR }
    }

    data class UploadStats(
        val uploaded: Int = 0,
        val duplicates: Int = 0
    )

    /** Load saved stats from persistent storage */
    private fun loadSavedStats(): UploadStats {
        val uploaded = prefs.getInt("total_uploaded", 0)
        val duplicates = prefs.getInt("total_duplicates", 0)
        return UploadStats(uploaded, duplicates)
    }

    /** Save stats to persistent storage */
    private fun saveStats(stats: UploadStats) {
        prefs.edit()
            .putInt("total_uploaded", stats.uploaded)
            .putInt("total_duplicates", stats.duplicates)
            .apply()
    }

    fun uploadPhotos(files: List<File>) {
        val accountName = session.accountName ?: return
        val folderName = session.driveFolderName
        val driveService = DriveService(getApplication(), accountName)

        val states = files.map { file ->
            UploadItemState(
                fileName = file.name,
                status = UploadItemState.Status.PENDING,
                sizeLabel = formatSize(file.length())
            )
        }.toMutableList()

        _uploadResults.value = states.toList()
        _isUploading.value = true

        viewModelScope.launch {
            // Start from saved stats — not from 0
            var uploaded = _uploadStats.value?.uploaded ?: 0
            var duplicates = _uploadStats.value?.duplicates ?: 0

            files.forEachIndexed { index, file ->
                states[index] = states[index].copy(status = UploadItemState.Status.UPLOADING)
                _uploadResults.postValue(states.toList())

                val result = driveService.uploadPhoto(
                    localFile = file,
                    userName = folderName,
                    onProgress = { progress ->
                        states[index] = states[index].copy(progress = progress)
                        _uploadResults.postValue(states.toList())
                    }
                )

                states[index] = when {
                    result.isDuplicate -> {
                        duplicates++
                        states[index].copy(
                            status = UploadItemState.Status.DUPLICATE,
                            progress = 100
                        )
                    }
                    result.success -> {
                        uploaded++
                        states[index].copy(
                            status = UploadItemState.Status.DONE,
                            progress = 100
                        )
                    }
                    else -> states[index].copy(
                        status = UploadItemState.Status.ERROR,
                        errorMessage = result.errorMessage
                    )
                }

                _uploadResults.postValue(states.toList())
                val newStats = UploadStats(uploaded, duplicates)
                _uploadStats.postValue(newStats)

                // Save to persistent storage after every upload
                saveStats(newStats)
            }

            _isUploading.postValue(false)
        }
    }

    private fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
            bytes >= 1_000 -> "%.0f KB".format(bytes / 1_000.0)
            else -> "$bytes B"
        }
    }

    fun getDisplayName() = session.displayName ?: session.email ?: "User"
    fun getInitials(): String {
        val name = session.displayName ?: session.email ?: "U"
        return name.split(" ").take(2).joinToString("") { it.first().uppercase() }
    }
}
